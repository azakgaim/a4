import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { RouterModule } from '@angular/router';

// components
import { AppComponent } from './app.component';
import { EventsLitComponent } from './events/events-list/events-list.component';
import { EventThumbnailComponent } from './events/event-thumbnail/event-thumbnail.component';
import { NavBarComponent } from './nav-bar/nav-bar.component';
import { EventDetailsComponent } from './events/event-details/event-details.component';
import { CreateEventComponent } from './events/create-event/create-event.component';
import { Error404Component } from './errors/error-404.component';
import { CreateSessionComponent } from './events/sessions/create-session/create-session.component';
import { SeesionListComponent } from './events/sessions/sessions-list/session-list.component';
import { CollapsableWellComponent } from './shared/collapsable-well.componemnt';

// services
import { EventsService } from './services/events.service';

// import { ToastrService } from './services/toastr.service';
import { TOASTR_TOKEN, Toastr} from './services/toastr.service';

import { EventRouteActivatorService } from './services/event-route-activator.service';
import { EventsListResolverService } from './services/events-list-resolver.service';
import { AuthService } from './services/auth.service';

// routes
import { routes } from './events.routes';

// pipes
import { DurationPipe } from './pipes/duration.pipe';

// 3rd party globals. Note: for large classes we can just use a type of any (although will weill
// not have intelly sence)
// declare const toastr: any;
declare const toastr: Toastr;

// TEST components
import { TreeNodeComponent } from './forums/forum-a1/tree-node.component';
import { TreeNodeMainComponent } from './forums/forum-a1/tree-node-main.component';

@NgModule({
  declarations: [
    AppComponent,
    EventsLitComponent,
    EventThumbnailComponent,
    NavBarComponent,
    EventDetailsComponent,
    CreateEventComponent,
    Error404Component,
    CreateSessionComponent,
    SeesionListComponent,
    CollapsableWellComponent,
    DurationPipe,

    TreeNodeComponent,
    TreeNodeMainComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    HttpModule,
    RouterModule.forRoot(routes)
  ],
  providers: [
    EventsService,
    // ToastrService,
    {
      provide: TOASTR_TOKEN,
      useValue: toastr
    },
    EventRouteActivatorService,
    EventsListResolverService,
    AuthService,
    {
      provide: 'canDeactivateCreateEvent',
      useValue: checkDirtyState
    }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }

function checkDirtyState(component: CreateEventComponent): boolean {
  if (component.isDirty) {
    return window.confirm('Abort creation of a new event?');
  }
  return true;
}
