// our root app component
// https://plnkr.co/edit/IrW82ye4NKK8cYEPxsFc?p=preview
import { Component, Input } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

@Component({
  selector: 'app-tree-node',  // selector: 'tree-node'
  template: `
  <div>{{node.name}}</div>
  <ul>
    <li *ngFor="let node of node.children">
      <app-tree-node  [node]="node"></app-tree-node>
    </li>
  </ul>
`
})

// export class TreeNode {
export class TreeNodeComponent {
  @Input() node;
}
