// https://plnkr.co/edit/IrW82ye4NKK8cYEPxsFc?p=preview

import { Component, OnInit } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

@Component({
  selector: 'app-tree-node-main',   // selector: 'my-app'
  template: `
    <div style="margin-left: 60px;">
      <h2>{{name}}</h2>
      <h3>
      <span *ngFor="let topic of node">
        <app-tree-node [node]="topic"></app-tree-node>
      </span>
      </h3>
    </div>
  `
})

// export class App
export class TreeNodeMainComponent implements OnInit {
  name: string;

  node = [
    {
    name: 'top level 1', children: [
      {name: 'a', children: []},
      {name: 'b', children: [
        {name: 'b_1', children: [
          {name: 'b_1_a', children: []},
          {name: 'b_1_b', children: []},
        ]},
        {name: 'b_2', children: []},
      ]},
      {name: 'c', children: [
        {name: 'c_1', children: []},
        {name: 'c_2', children: []},
        {name: 'c_3', children: []},
     ]}
  ]},
  {
  name: 'top level 2', children: [
    {name: 'A', children: []},
    {name: 'B', children: []},
    {name: 'C', children: [
      {name: 'D', children: []},
      {name: 'E', children: []},
      {name: 'F', children: []},
   ]}
]},
  ];

  constructor() { }

  ngOnInit() {
    this.name = 'Forum topics';
  }
}
