
import { Routes } from '@angular/router';

// components
import { EventsLitComponent } from './events/events-list/events-list.component';
import { EventDetailsComponent } from './events/event-details/event-details.component';
import { CreateEventComponent } from './events/create-event/create-event.component';
import { Error404Component } from './errors/error-404.component';
import { CreateSessionComponent } from './events/sessions/create-session/create-session.component';

// services
import { EventRouteActivatorService } from './services/event-route-activator.service';
import { EventsListResolverService } from './services/events-list-resolver.service';

// lazy loading modules
import { UserModule } from './user/user.module';


// TEST components
import { TreeNodeComponent } from './forums/forum-a1/tree-node.component';
import { TreeNodeMainComponent } from './forums/forum-a1/tree-node-main.component';

export const routes: Routes = [
  {path: 'events', component: EventsLitComponent, resolve: { events: EventsListResolverService } },
  {path: 'events/new', component: CreateEventComponent, canDeactivate: ['canDeactivateCreateEvent']},
  {path: 'events/:id', component: EventDetailsComponent, canActivate: [EventRouteActivatorService]},
  {path: '404', component: Error404Component},
  {path: '', redirectTo: '/events', pathMatch: 'full'},

  // this line works in Angular 2
  // {path: 'user', loadChildren: './user/user.module#UserModule'},

  // this line works in Angular 5
  {path: 'user', loadChildren: () => UserModule},

  {path: 'events/session/new', component: CreateSessionComponent},

  {path: 'forum', component: TreeNodeMainComponent}
];
